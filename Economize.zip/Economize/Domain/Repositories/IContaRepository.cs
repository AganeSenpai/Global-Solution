﻿using Economize.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Economize.Domain.Repositories
{
    public interface IContaRepository
    {
        Task InserirConta(ContaDeLuz conta);
        Task<IEnumerable<ContaDeLuz>> ObterContas();
        Task<IEnumerable<ContaDeLuz>> ObterContasPorCliente(int idCliente);
        Task<IEnumerable<Cliente>> ObterClientes();
    }
}
