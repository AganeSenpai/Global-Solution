﻿namespace Economize.Domain.Entities
{
    public class ContaDeLuz
    {
        public int Id { get; set; }
        public string ?NomeCliente { get; set; }
        public decimal ValorConta { get; set; }
        public DateTime DataVencimento { get; set; }
        public int IdCliente { get; internal set; }
    }
}


