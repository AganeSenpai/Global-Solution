﻿namespace Economize.Domain.Entities
{
    public class Cliente
    {
        public int Id { get; set; }
        public string ?Nome { get; set; }
    }
}
