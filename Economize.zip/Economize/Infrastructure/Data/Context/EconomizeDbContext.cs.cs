﻿using Microsoft.EntityFrameworkCore;
using Economize.Domain.Entities;

namespace Economize.Infrastructure.Data.Context
{
    public class EconomizeDbContext : DbContext
    {
        public EconomizeDbContext(DbContextOptions<EconomizeDbContext> options)
            : base(options) { }

        public DbSet<ContaDeLuz> Contas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            //modelBuilder.HasDefaultSchema("GLOBAL_SOLUTION");

            
            modelBuilder.Entity<ContaDeLuz>(entity =>
            {
                entity.ToTable("CONTAS_DE_LUZ");

                entity.HasKey(c => c.Id);

                entity.Property(c => c.NomeCliente)
                      .IsRequired()
                      .HasMaxLength(100);

                entity.Property(c => c.ValorConta)
                      .HasColumnType("NUMBER(10,2)");

                entity.Property(c => c.DataVencimento)
                      .HasColumnType("DATE");
            });
        }
    }
}

