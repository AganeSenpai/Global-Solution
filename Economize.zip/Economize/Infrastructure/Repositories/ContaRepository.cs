﻿using Economize.Domain.Entities;
using Economize.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Economize.Infrastructure.Repositories
{
    public class ContaRepository : IContaRepository
    {
        private readonly List<ContaDeLuz> _contas = new(); // Simulação de dados

        public async Task InserirConta(ContaDeLuz conta)
        {
            _contas.Add(conta);
            await Task.CompletedTask;
        }

        public async Task<IEnumerable<ContaDeLuz>> ObterContas()
        {
            return await Task.FromResult(_contas);
        }

        public async Task<IEnumerable<ContaDeLuz>> ObterContasPorCliente(int idCliente)
        {
            return await Task.FromResult(_contas.Where(c => c.IdCliente == idCliente));
        }

        public async Task<IEnumerable<Cliente>> ObterClientes()
        {
            // Simulação de extração de clientes únicos
            var clientes = _contas
                .Select(c => new Cliente
                {
                    Id = c.IdCliente,
                    Nome = c.NomeCliente
                })
                .Distinct();

            return await Task.FromResult(clientes);
        }
    }
}




