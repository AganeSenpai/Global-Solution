﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Economize.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CONTAS_DE_LUZ",
                columns: table => new
                {
                    Id = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NomeCliente = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    ValorConta = table.Column<decimal>(type: "NUMBER(10,2)", nullable: false),
                    DataVencimento = table.Column<DateTime>(type: "DATE", nullable: false),
                    IdCliente = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CONTAS_DE_LUZ", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CONTAS_DE_LUZ");
        }
    }
}
