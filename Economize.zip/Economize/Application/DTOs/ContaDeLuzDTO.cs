﻿namespace Economize.Application.DTOs
{
    public class ContaDeLuzDTO
    {
        public string ?NomeCliente { get; set; }
        public decimal ValorConta { get; set; }
        public DateTime DataVencimento { get; set; }
        public object ?IdCliente { get; internal set; }
    }
}






