﻿using Economize.Application.DTOs;
using Economize.Application.Interfaces;
using Economize.Domain.Entities;
using Economize.Domain.Repositories;


namespace Economize.Application.Services
{
    public class ContaService : IContaService
    {
        private readonly IContaRepository _contaRepository;

        public ContaService(IContaRepository contaRepository)
        {
            _contaRepository = contaRepository;
        }

        public async Task InserirConta(ContaDeLuzDTO contaDto)
        {
            var conta = new ContaDeLuz
            {
                NomeCliente = contaDto.NomeCliente,
                ValorConta = contaDto.ValorConta,
                DataVencimento = contaDto.DataVencimento
            };

            await _contaRepository.InserirConta(conta);
        }

        public async Task<IEnumerable<ContaDeLuzDTO>> ObterContas()
        {
            var contas = await _contaRepository.ObterContas();

            return contas.Select(c => new ContaDeLuzDTO
            {
                NomeCliente = c.NomeCliente,
                ValorConta = c.ValorConta,
                DataVencimento = c.DataVencimento
            }).ToList();
        }

        public async Task<decimal> CalcularGasto10Meses(int idCliente)
        {
            var contas = await _contaRepository.ObterContasPorCliente(idCliente);
            var totalGasto = contas.Sum(c => c.ValorConta);

            return totalGasto * 10;
        }

        public async Task<IEnumerable<string>> ListarClientes()
        {
            var contas = await _contaRepository.ObterContas();

            // Retorna uma lista de nomes de clientes únicos
            return contas.Select(c => c.NomeCliente).Distinct().ToList();
        }
    }
}






