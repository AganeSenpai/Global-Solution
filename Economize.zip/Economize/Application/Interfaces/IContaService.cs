﻿using Economize.Application.DTOs;


namespace Economize.Application.Interfaces
{
    public interface IContaService
    {
        Task InserirConta(ContaDeLuzDTO conta);
        Task<IEnumerable<ContaDeLuzDTO>> ObterContas();
        Task<decimal> CalcularGasto10Meses(int idCliente);
        Task<IEnumerable<string>> ListarClientes(); // Retorna nomes dos clientes
    }
}


