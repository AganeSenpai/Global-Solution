using Economize.Application.DTOs;
using Economize.Application.Interfaces;
using Economize.Application.Services;
using Economize.Domain.Repositories;
using Economize.Infrastructure.Data.Context;
using Economize.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Configura��o dos servi�os
builder.Services.AddControllers();  // Adiciona os servi�os de controle (controllers)

builder.Services.AddDbContext<EconomizeDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("DefaultConnection")));

// Registrando reposit�rios e servi�os
builder.Services.AddScoped<IContaRepository, ContaRepository>();
builder.Services.AddScoped<IContaService, ContaService>();

// Adicionando Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Economize API", Version = "v1" });
});

var app = builder.Build();

// Configura��o do pipeline de middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Economize API v1");
        c.RoutePrefix = string.Empty;  // Faz com que o Swagger UI seja acessado diretamente pela raiz do aplicativo
    });
}

// Redireciona qualquer acesso � raiz para o Swagger
app.MapGet("/", () => Results.Redirect("/swagger/index.html"));

// For�a o redirecionamento para HTTPS
app.UseHttpsRedirection();

// Mapeamento de controladores para que as rotas funcionem
app.MapControllers();

app.Run();  // Executa a aplica��o





