﻿using Economize.Application.DTOs;
using Economize.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Economize.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContasController : ControllerBase
    {
        private readonly IContaService _contaService;

        public ContasController(IContaService contaService)
        {
            _contaService = contaService;
        }

        // Inserir uma nova conta
        [HttpPost("inserir-conta")]
        public async Task<IActionResult> InserirConta([FromBody] ContaDeLuzDTO contaDto)
        {
            if (contaDto == null)
                return BadRequest("Os dados da conta não podem ser nulos.");

            try
            {
                await _contaService.InserirConta(contaDto);
                return Ok(new { Mensagem = "Conta inserida com sucesso." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao inserir a conta: {ex.Message}");
            }
        }

        // Calcular gasto total em 10 meses para um cliente
        [HttpGet("calcular-gasto/{idCliente}")]
        public async Task<IActionResult> CalcularGasto10Meses(int idCliente)
        {
            if (idCliente <= 0)
                return BadRequest("O ID do cliente deve ser maior que zero.");

            try
            {
                var gastoTotal = await _contaService.CalcularGasto10Meses(idCliente);
                return Ok(new { GastoTotal = gastoTotal });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao calcular o gasto: {ex.Message}");
            }
        }

        // Listar todas as contas
        [HttpGet("listar-contas")]
        public async Task<IActionResult> ListarContas()
        {
            try
            {
                var contas = await _contaService.ObterContas();
                return Ok(contas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao listar as contas: {ex.Message}");
            }
        }
    }
}




